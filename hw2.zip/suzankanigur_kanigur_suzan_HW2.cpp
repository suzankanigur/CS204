#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>

using namespace std;

struct node
{
	int month, year;
	vector<string> cards;
	node* next;
};

bool cardNumCheck(string cardnum){
    if(cardnum.length()!=16){
		return false;
	}
    for(int i=0; i<16; i++) {
        if(!((cardnum[i]>'0' || cardnum[i]=='0') && (cardnum[i]<'9' || cardnum[i]=='9'))) { // checking if the cardnum is integer
            return false;
        }
    }
    return true;
}

bool userDateCheck(string month_user, string year_user){  // checking the validity of the dates that user entered

	for(int i=0; i<month_user.length() ; i++) {	
		if(!(month_user[i]>='0' && month_user[i]<='9')){
			return false;
		}
	}
	if(!(1 <= stoi(month_user) && stoi(month_user)<= 12)) {
		return false;
	}

	for(int i=0; i<year_user.length() ; i++) {
		if(!(year_user[i]>='0' && year_user[i]<='9')){
			return false;
		}
	}
	return true;
}



void findLocation(node * &head, int month_card, int year_card, string cardsnum){ //if node does not exist, then find a proper place
	 
	node *new_node = new node;
	node *current = head;
	node *previous;  


	while(current != NULL){

		if(current -> year == year_card && current -> month == month_card){  // if everything is the same, directly add the numbers to the vector
			current -> cards.push_back(cardsnum);
			cout << "Node with expiration date " << month_card << " " << year_card << " already exists. " <<endl;  
			break;
		}
		
		if(current -> year > year_card){ 
			if(current == head){  // if no nodes exists, we need to create one
				new_node = new node; 
				head = new_node;
				new_node -> month = month_card;
				new_node -> year = year_card;
				new_node -> cards.push_back(cardsnum);
				new_node -> next = current;	 
			}
			else{
				new_node = new node;
				previous -> next = new_node;
				new_node -> month = month_card;
				new_node -> year = year_card;
				new_node -> cards.push_back(cardsnum);
				new_node -> next = current;	


			}
			cout<<"New node is created with expiration date: "<< month_card<<" "<< year_card<<endl;
			break;

		}
		else if(current -> year == year_card && current -> month > month_card){  // years are the same, months are not
			if(current == head){
				new_node = new node;
				head = new_node;
				new_node -> month = month_card;
				new_node -> year = year_card;
				new_node -> cards.push_back(cardsnum);
				new_node -> next = current;	

			}
			else{
				new_node = new node;
				previous -> next = new_node;
				new_node -> month = month_card;
				new_node -> year = year_card;
				new_node -> cards.push_back(cardsnum);
				new_node -> next = current;	

			}
			cout<<"New node is created with expiration date: "<< month_card<<" "<< year_card<<endl;
			break;
		}
		previous = current;
		current= current -> next;
	}

	if(current == NULL){ //adding the new node to end 
		new_node= new node;
		new_node -> cards.push_back(cardsnum);
		new_node -> month = month_card;
		new_node -> year = year_card;
		new_node -> next = current;	
		new_node -> next == NULL;
		previous -> next = new_node;

		cout<<"New node is created with expiration date: "<< month_card<<" "<< year_card<<endl;
	
	
	}
}

void searchLoop(node *&head, int month_card, int year_card, string cardsnum)  
{
	node* new_node = NULL;
	node *ptr = head;
	new_node = new node;

	if(head == NULL){  // if there is no node yet, create one
	
		new_node -> cards.push_back(cardsnum);
		new_node -> month = month_card;
		new_node -> year = year_card;
		new_node -> next = NULL;
		head = new_node;
		cout << "New node is created with expiration date: " << month_card << " " << year_card << endl;
		cout << "Credit card " <<cardsnum << " added to node "<< month_card << " " << year_card << endl;
		cout << "***************" << endl;
	}

	else{
		findLocation(head, month_card, year_card, cardsnum);
		cout << "Credit card " << cardsnum << " added to node "<< month_card << " " << year_card << endl;
		cout << "***************" << endl;
	}
}

void DeleteList (node *new_node){  //deleting nodes
  if (new_node != NULL) {
      DeleteList(new_node->next);
      delete new_node;
  }
}


int main(){

	string filename, cardsnum;
	int option, year_user, month_user;
   ifstream file;
   cout << "Enter filename: ";
   cin >> filename;
	file.open(filename.c_str());
	while(file.fail())
	{
		file.clear();
		cout<<"Cannot find a file named "<< filename << endl;	
		cout << "Enter filename: ";
		cin >> filename;  // we need to keep asking until it works
		file.open(filename.c_str());
	}
	string line;
	node *new_node, *head = NULL;
	node *p;
	while(getline(file,line)){  //reading line by line
		istringstream input(line);  // to get line as an input from the keyboard
		string creditNum;
		int month_card, year_card;
		input >> cardsnum >> month_card >> year_card; 
		searchLoop(head, month_card, year_card, cardsnum);
	}
	cout << endl;
	do {
		new_node = head;
		cout << "1. Display List" << endl; 
		cout << "2. Card Search" << endl;
		cout << "3. Delete Cards (with respect to Expiration Date)" << endl;
		cout << "4. Exit" << endl << endl;
		cout << "Please choose option from the menu: ";
		cin >> option;
		cout << endl;
		
		if(option==1){  // display all the card numbers according to their dates
			while(new_node!=NULL){
				cout << "Expiration Date: " << new_node -> month << " " << new_node -> year << endl;
				for(int i = 0; i < new_node->cards.size(); i++){   
					cout << i+1 << ") " << new_node -> cards[i] << endl; 
				}
				cout << "-------------------" << endl << endl;
				new_node = new_node -> next;
			}

		}
		else if(option==2){  // card search
			cout << "Please enter the credit card number: ";
			string card;
			cin >> card;
			while(!cardNumCheck(card)){  // if the cardnumber format is valid
				cout << "Invalid format!"<< endl;
				cout << "Please enter the credit card number: ";
				cin >> card; 
				
			}
			bool isFound = false;
			while(new_node != NULL){
				int i = 0;
				while(i < new_node -> cards.size()){ 
					if(new_node -> cards[i] == card){
						cout << "There exists a credit card given number " << card <<  " with expiration date: " << new_node -> month << " " << new_node -> year << endl;
						isFound = true;
					}
					i++;
				}
				new_node = new_node -> next;
			}
			if(!isFound){
				cout << "There is no credit card with given credit card number: " << card << endl;
			}
			cout << endl;
		}

		else if(option == 3){ // Deleting cards with respect to expiration date
			node *afterHead;
			node *prev;
			afterHead = head-> next;
			cout << "Please enter month and year: ";
			cin >> month_user >> year_user;
			while(!userDateCheck(to_string(month_user), to_string(year_user))){
				cout << "Invalid Date!" << endl;
				cout << "Please enter month and year: ";
				cin >> month_user >> year_user;
			}
			cout << endl;
			bool check = true;
			while(new_node != NULL && check){
					if(new_node -> month == month_user && new_node -> year == year_user ){
						cout << "Node with expiration date " << month_user << " " << year_user << " and the following credit cards have been deleted!"<< endl;
						for(int j = 0; j < new_node -> cards.size(); j++){ 
							cout << j+1 << ") " << new_node -> cards[j] << endl; 
						}
						if(new_node == head){  // if it is at the beginning, we should also direct the head into the next node
							head = head -> next;
							delete new_node;
							check = false;

						}
						else if(new_node != head){
							prev -> next = new_node -> next;
							delete new_node;
							check = false;

						}
					
					}
					else{
						prev = new_node;
						new_node = new_node -> next;
						
					}
					
				if(new_node == NULL) {
						cout << "There is no node with expiration date " << month_user << " " << year_user << ", nothing deleted!" << endl;
						check = false;
				}
			}
			cout << endl;
		}
		else if(option == 4){
			cout << "Terminating!!!" << endl;
			return 0;
		}
		else{
			cout << "Invalid option!" << endl; //if the option is not 1, 2 or 3.
		}	
	} while(option != 4); // it should directly terminate

	DeleteList(head);
	return 0;
}



