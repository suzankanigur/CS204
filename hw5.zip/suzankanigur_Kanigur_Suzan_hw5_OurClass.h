#ifndef _OURCLASS_H
#define _OURCLASS_H

#include <ostream>


using namespace std;
class IntegerSet
{
	private:
		//our Private data;
		int oursize;
		int* ourfront;
		

	public:
	IntegerSet(); 
	IntegerSet(int size);
	IntegerSet(IntegerSet & right); 
	~IntegerSet(); 
	//for non member functions we implement getters
	 int* getfront() const{
	return ourfront;};
	 int getsize() const{
	return oursize;};


	//member operator declarations are below
	IntegerSet &operator=(const IntegerSet &right); 
	IntegerSet& operator+=(const IntegerSet &right); 
	IntegerSet operator * (const IntegerSet &);
	
};

//free operators that we need to implemnt.
IntegerSet operator+ (const IntegerSet & left,const IntegerSet  &right);
IntegerSet operator+ (const IntegerSet & left,int right);
ostream & operator << (ostream & ,const IntegerSet & x);
bool operator <=( int s,IntegerSet& );  
bool operator !=(const IntegerSet & left,const IntegerSet  &right);
bool operator <=(const IntegerSet & left,const IntegerSet  &right);
#endif