
#include"suzankanigur_Kanigur_Suzan_hw5_OurClass.h"
#include<iostream>
#include<string>

//below are implementions of our default,copy and variabled constructors. take right hand side and copy or insert it to left.
IntegerSet::IntegerSet() //default const.
{
	this->ourfront = nullptr;
	this->oursize = 0;
	
}
IntegerSet::IntegerSet( int size)
{
	this->oursize=0;
	this->ourfront=new int [size];

	for(int i = 0; i < size; i++)
	{
		this->ourfront[i] = i;
		this->oursize++;
	}

}
IntegerSet::IntegerSet(IntegerSet & right) //copy constructor
{
	this->oursize=right.oursize;
	this->ourfront=new int [oursize];
	for(int i = 0; i < oursize; i++)
	{
		this->ourfront[i] = right.ourfront[i];  
	}

}
IntegerSet::~IntegerSet() //destructor
{
	this->oursize=0;
	delete [] this->ourfront;
}

//our operator that makes left equals to right by equalling right elements to left individually.
IntegerSet &IntegerSet:: operator=(const IntegerSet & right)
{
	if( right != *this)
	{

		this->oursize = 0;
		delete[] this->ourfront;

		this->oursize =right.oursize;
		this->ourfront = new int[right.oursize];
		

		for(int i = 0; i < right.oursize; i++) //inserting rhs'S element to our new left side.
		{
			this->ourfront[i] = right.ourfront[i]; // assign content
		}
	
	}
	return *this;

}
//our operator checks the right hand side elements if there are not exist on left, it update left
IntegerSet& IntegerSet::operator+=(const IntegerSet &right){
	
		int same_element_count=0;

		for(int i = 0; i < right.oursize; i++) //inserting rhs'S element to our new left side.
		{
			for(int x=0;x<this->oursize;x++){
					if(this->ourfront[x] == right.ourfront[i]) //any of them equall it means it is already exist.
							same_element_count++;
			}
		}
		int updatedsize=this->oursize + right.oursize - same_element_count;
		int * temp=new int [updatedsize];


		for(int x=0;x<this->oursize;x++){//copying leftside first.
			temp[x]=this->ourfront[x];
		}
		int inserting_place=this->oursize; //last index of left.
		bool flag=true;

	for(int i = 0; i < right.oursize; i++) //inserting rhs'S element to our new left side.
		{
		flag=true;
		for(int x=0;x<this->oursize;x++){
			if(this->ourfront[x] == right.ourfront[i]){
			 flag=false;} //any of them equall it means it is already exist.
							}
		
		
		if(flag){temp[inserting_place]=right.ourfront[i];
		inserting_place++;}
		}
		


		this->ourfront=temp;
		this->oursize=updatedsize;

		return *this;

} 

//our * operator looks for common elements and return a new object of �temset.
IntegerSet IntegerSet::operator * (const IntegerSet &right){
	int que=0;
	int same_element_count=0;
	for(int i = 0; i < right.oursize; i++) //traversing rhs'S element 
		{
			for(int x=0;x<this->oursize;x++){//traversing left.
					if(this->ourfront[x] == right.ourfront[i]) //any of them equall it means it is already exist.
							same_element_count++;
			}
		}
	//we found same element count than.
	
	IntegerSet result(same_element_count);
	
	for(int i = 0; i < right.oursize; i++) //traversing rhs'S element 
		{
			for(int x=0;x<this->oursize;x++){//traversing left.
					if(this->ourfront[x] == right.ourfront[i]) //any of them equall it means it is already exist.
							{result.getfront()[que]=right.ourfront[i];
								que++;}
			}
		}



	return result;

}


//free operator functions;
IntegerSet operator+ (const IntegerSet & left,const IntegerSet  &right) {
	int ls=left.getsize();
	int rs=right.getsize();
	int *rf=right.getfront();
	int *lf=left.getfront();

	int same_element_count=0;

		for(int i = 0; i <rs; i++) //inserting rhs'S element to our new left side.
		{
			for(int x=0;x<ls;x++){
					if(lf[x] ==rf[i]) //any of them equall it means it is already exist.
							same_element_count++;
			}
		}
		int updatedsize=ls + rs - same_element_count;

		int * temp=new int [updatedsize];


		for(int x=0;x<ls;x++){//copying leftside first.
			temp[x]=lf[x];
		}
		int inserting_place=ls; //last index of left.
		bool flag=true;

	for(int i = 0; i <rs; i++) //inserting rhs'S element to our new left side.
		{
		flag=true;
		for(int x=0;x<ls;x++){
			if(lf[x] == rf[i]){
			 flag=false;} //any of them equall it means it is already exist.
							}
		
		
		if(flag){temp[inserting_place]=rf[i];
		inserting_place++;}
		}

	IntegerSet rtrn(updatedsize);
	for(int x=0;x<updatedsize;x++){//copying leftside first.
			rtrn.getfront()[x]=temp[x];
		}
	return rtrn;

}
IntegerSet operator+ (const IntegerSet & left,int right){
	int ls=left.getsize();
	int *lf=left.getfront();
	bool exist=false;
	
	for(int x=0;x<ls;x++){
					if(lf[x] ==right) //traverse all elements and find is exist or not
							exist=true;
			}
		
		int updatedsize=ls;
		if(!exist)
			updatedsize++;
		 int  * temp=new int [updatedsize];

		for(int x=0;x<ls;x++){//copying leftside first.
			temp[x]=lf[x];
		}


	
		
		if(!exist){temp[ls]=right;  //if it is not exist insert it, else return same.
		}

	IntegerSet rtrn(updatedsize);
	for(int x=0;x<updatedsize;x++){//copying leftside first.
			rtrn.getfront()[x]=temp[x];
		}
	return rtrn;


} 

ostream & operator << (ostream & left,const IntegerSet & x){
	string output="{}";
if(x.getsize()!=0)
	{	
	output="{";
	for(int i = 0; i < x.getsize(); i++)
	{
		output+=(to_string(x.getfront()[i]));
		output+=",";
	}
	output.pop_back(); //we pop it because we add one more , 
	output.append("}");
}
cout << output;
return left;
}
bool operator <=( int element ,IntegerSet & right ){
	bool exist=false;
	for(int i=0;i<right.getsize();i++){  //traversing right.
		if (right.getfront()[i]==element)
			exist=true;  //If th�s elemeent exist we should return the true value.

	}
	return exist;

}  
bool operator !=(const IntegerSet & left,const IntegerSet  &right){
	
	for(int x=0;x<left.getsize();x++){
		for(int i=0;i<right.getsize();i++){
			if (right.getfront()[i]==left.getfront()[x])
			{break;}
			  if (x == i) 
            return 1; //if the upper code not broked than the element wont exist in other subset.
			}

	}
	if(left.getsize()==right.getsize())  //if upper not returned true, now we need to check sizes because it may be subset too.
		return 0;
	else
		return 1;
}  

bool operator <=(const IntegerSet & left,const IntegerSet  &right){
	
	for(int x=0;x<left.getsize();x++){
		for(int i=0;i<right.getsize();i++){
			if (right.getfront()[i]==left.getfront()[x])
			{break;}
			  if (x == i) 
            return 0; //if the upper code not broked than the element wont exist in other subset.
			}

	}
	
	return 1;
}  

