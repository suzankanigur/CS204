#ifndef _HEADER_H
#define _HEADER_H

#include <string>
#include <iostream>
#include <vector>

using namespace std;
class Board
{
private:
	char GameBoard[2][6];
public:
	Board(); //ok
	void displayBoard(); //ok
	char getOwner(int,int); //ok
	void setOwner(int,int,char); //ok
	bool isFull(); //ok
	int countOwnedCells(char); //ok
};

class Player{
private:
	char s;
	int row;
	int col;
	int dir;
	Board & gameboard;
public:
	Player(Board& brd ,char sign,int i) : row(0), col(0),gameboard(brd) , s(sign), dir(i) {};
	void move(int);
	void claimOwnership();
	bool wins();
	int getRow();
	int getCol();
};





#endif