#include<iostream>
#include<string>
#include "suzankanigur_Kanigur_Suzan_hw6_Header.h"
using namespace std;

//default constructor of our main game board
Board::Board() // ok
{
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<2; j++)
		{
			this->GameBoard[j][i]='-';
		}
	}
}
//our function that prints the last version of board
void Board::displayBoard()
{
	for(int i=0; i<2; i++)
	{
		for(int j=0; j<6; j++)
		{
			cout<<this->GameBoard[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl;
}
//function that takes the coordinate as parameter and returns the owned player's char
char Board::getOwner(int x, int y)
{

	if(this->GameBoard[x][y]=='-')
	{
		return '-';
	}
	if(this->GameBoard[x][y]=='A')
	{
		return 'A';
	}
	if(this->GameBoard[x][y]=='B')
	{
		return 'B';
	}
}
//function for checking the board is full of player chars or not
bool Board::isFull()
{
	bool retrn=true;
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<2; j++)
		{
			if(this->GameBoard[j][i]=='-')
			{
				retrn= false;
			}
		}
	}
	return retrn;
}
//funcion for update the specific coordinate with players sign
void Board::setOwner(int row, int col, char z)
{
	this->GameBoard[row][col]=z;
}
//function that reutrns the count of specific char sign 
int Board::countOwnedCells(char x)
{
	int count=0;
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<2; j++)
		{
			if(this->GameBoard[j][i]==x)
			{
				count+=1;
			}
		}
	}
	return count;
}
//our main move function that updates the coordinates of our players
void Player::move(int a) 
{ // if direction is 1, it means player 1 moves clockwise.
	if(this->dir==1){
		for(int x=0;x<a;x++){
			if(this->row==0){
				if(this->col<5)
					{this->col++;}
				else if(this->col==5)
					{this->row++;}
			
			}
			else if(this->row==1){
				if(this->col>0)
					{this->col--;}
				else if(this->col==0)
					{this->row--;}
			
			
			}

		}
	
	
	}

	// if direction is 0, it means player 2 moves counter clockwise.
	if(this->dir==0){
	for(int x=0;x<a;x++){
			if(this->row==0){
				if(this->col==0)
					{this->row++;}
				else if(this->col>0)
					{this->col--;}
			
			}
			else if(this->row==1){
				if(this->col<5)
					{this->col++;}
				else if(this->col==5)
					{this->row--;}
			
			
			}
	}
	
	}
	//we move our pawns on upper side of code.
	//now we should sign the square.

	if(this->gameboard.getOwner(this->row,this->col)=='-')
	{
		this->gameboard.setOwner(this->row,this->col,this->s);
	}



}
//if is not ownered yet, than call set function.
void Player::claimOwnership()
{
if(gameboard.getOwner(this->getRow(),this->getCol())=='-')
	{
		gameboard.setOwner(this->getRow(),this->getCol(),this->s);
	}
else
	return;
}
//simple getter functions
int Player::getCol()
{
	return this->col;
}
int Player::getRow()
{
	return this->row;
}
//bool for is our player win or not
bool Player::wins()
{
	if(gameboard.countOwnedCells(this->s)!=7)
	{
		return false;
	}

	else
		return true;
}
