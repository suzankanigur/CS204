#include <iostream>
#include <random> 
#include <time.h>
#include <thread>
#include <mutex>
#include <chrono>
#include <iomanip>        // for put_time
#include <ctime>
#include "suzankanigur_Kanigur_Suzan_hw8_DynIntQueue.h"
using namespace std;

HW8DynIntQueue myQueue;
mutex coutMutex,queueMutex; //2 different mutex
int customerNum, minTimeCustomer, maxTimeCustomer, minTimeCashier, maxTimeCashier, cashier2_treshold;
int counter = 0;
int i=1; //to make sure that all threads calling this function use same i.

int random_range(const int & min, const int & max) { 
	static mt19937 generator(time(0)); 
	uniform_int_distribution<int> distribution(min, max); 
	return distribution(generator); 
}

void customer()  
{
	//for(int i = 1; i < customerNum; i++)
	for(;i<=customerNum;)
	{
		int time1 = random_range(minTimeCustomer, maxTimeCustomer); //Sleep for customer arrival. To represent interarrival times
		this_thread::sleep_for(chrono::seconds(time1)); 
		queueMutex.lock();
		myQueue.enqueue(i);
		i++;
		queueMutex.unlock();
		//Time needs to be calculated and then thread can wait. When its turn comes, it can print out.
		
		time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
		struct tm *ptm = new struct tm; 
		localtime_s(ptm, &tt); 
		coutMutex.lock();		
		cout <<"New customer with ID "<<  i-1  << " has arrived (queue size is "<< myQueue.getCurrentSize() << "):"<<put_time(ptm,"%X") <<endl;
		coutMutex.unlock();
	}
}

void cashier(int cashierId)  
{
	int cust, time2;
	bool failed = false; //Fail mechanism, for ex. when one customer is left and there are 2 cashiers
	
	while(counter < customerNum)
	{	
		int size = myQueue.getCurrentSize();
		if(((cashierId==2)&&(size==cashier2_treshold||size>cashier2_treshold))||(cashierId==1))
		{

			//sleep the cashier threads just after starting the thread func
			time2 = random_range(minTimeCashier, maxTimeCashier); //time the cashier spends
			this_thread::sleep_for(chrono::seconds(time2));

			queueMutex.lock();
			if (!myQueue.isEmpty()) 
			{  
				myQueue.dequeue(cust);
				counter++;
				time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
				struct tm *ptm = new struct tm; 
				localtime_s(ptm, &tt); 
				coutMutex.lock();
				cout<<"Cashier "<< cashierId <<"  started transaction with customer "<< cust  <<"  (queue size is " << myQueue.getCurrentSize() << "):" << put_time(ptm,"%X") <<endl;
				coutMutex.unlock();
			}
			else
				failed=true;
			queueMutex.unlock();
			time2 = random_range(minTimeCashier, maxTimeCashier); 
			this_thread::sleep_for(chrono::seconds(time2)); 
			time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
			struct tm *ptm = new struct tm; 
			localtime_s(ptm, &tt); 
			coutMutex.lock();
			if(!failed)//check if failed.
				cout<< "Cashier " << cashierId <<" finished transaction with customer "<< cust << " " << put_time(ptm,"%X") <<endl;
			coutMutex.unlock();
		}
	}
}

int main(){
	
	cout<<"Please enter the total number of customers: ";
	cin>>customerNum;
	cout<<"Please enter the number of customers waiting in the queue to open the second cashier: ";
	cin>>cashier2_treshold;
	cout<<"Please enter the inter-arrival time range between two customers:"<<endl;
	cout<<"Min: ";
	cin>>minTimeCustomer;
	cout<<"Max: ";
	cin>>maxTimeCustomer;
	cout<<"Please enter the checkout time range of cashiers:"<<endl;
	cout<<"Min: ";
	cin>>minTimeCashier;
	cout<<"Max: ";
	cin>>maxTimeCashier;
	
	time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
	struct tm *ptm = new struct tm; 
	localtime_s(ptm, &tt); 
	cout << "Simulation starts " << put_time(ptm,"%X") << endl;
	thread thr0(&customer);
	thread thr1(&cashier,1);
	thread thr2(&cashier,2);
	thr0.join();
	thr1.join();
	thr2.join();	 
	tt= chrono::system_clock::to_time_t (chrono::system_clock::now());
	localtime_s(ptm, &tt);
	cout << "End of the simulation ends: " << put_time(ptm,"%X") << endl;
	return 0;
}
