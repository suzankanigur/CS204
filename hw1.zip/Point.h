#ifndef _POINT_H
#define _POINT_H
#include <iostream>
#include <string>
using namespace std;

class Point
{
    private:
    int x_pos;
    int y_pos;
    bool up_wall;
    bool down_wall;
    bool right_wall;
    bool left_wall;
    bool visited;
    public:
    Point(int x, int y)
        :x_pos(x),y_pos(y),up_wall(true),down_wall(true),right_wall(true),left_wall(true),visited(false)
    {
        
    }
    void knockdownWall(int direction)
    //0 for up, 1 for right,2 for down, 3 for left
    {
        if(direction == 0)
            up_wall = false;
        else if(direction == 1)
            right_wall = false;
        else if(direction == 2)
            down_wall = false;
        else
            left_wall = false;
    }

    bool getWall(int direction)
    //0 for up, 1 for right,2 for down, 3 for left
    {
        if(direction == 0)
            return up_wall;
        else if(direction == 1)
            return right_wall;
        else if(direction == 2)
            return down_wall;
        else
            return left_wall;
    }

    void visit()
    {
        visited = true;
    }

    bool isVisited()
    {
        return visited;
    }

    bool isValid(int xlim, int ylim)
    {
        return x_pos>=0 && y_pos>=0 && x_pos<xlim && y_pos<ylim;
    }
    
    int get_x()
    {
        return x_pos;
    }

    int get_y()
    {
        return y_pos;
    }
	void unvisit()
    {
        visited = false;
    }
};

#endif