#include <iostream>
#include <string>
#include "CreditCards.h"
#include <fstream>
#include <sstream>


using namespace std;

void saveCC(CardList & Cards);
bool cardNumCheck(string cnum);
bool bulkDelCheck(string month, string year);

int main()
{

	CardList Cards;

	while (true)
	{
		string opt = "";
		cout <<endl<<"1) Upload Card(s) from a File" <<endl;
		cout<<"2) Display List Chronological"<<endl;
		cout<<"3) Display List Reverse Chronological"<<endl;
		cout<<"4) Card Search"<<endl;
		cout<<"5) Bulk Delete"<<endl;
		cout<<"6) Exit"<<endl;
		cout<<"Please choose option from the menu: ";

		cin >> opt;


		if(opt == "1")
		{
			saveCC(Cards);
		}
		else if(opt == "2")
		{
			Cards.displayListChronological();
		}
		else if(opt == "3")
		{
			Cards.displayListReverseChronological();
		}
		else if(opt == "4")
		{
			string cnum = "";
			cout <<"Please enter the credit card number: ";
			cin >> cnum;

			if(cardNumCheck(cnum))
			{
				Cards.cardSearch(cnum);
			}
			else
			{
				cout << "Invalid format! "<<endl;
			}


		}
		else if(opt == "5")
		{
			string month, year;
			cout <<"Please enter month and year: ";
			cin >> month >> year;

			if(bulkDelCheck(month,year))
			{
				Cards.bulkDelete(stoi(month),stoi(year));
			}
			else
				cout<<"Invalid format!"<<endl;

		}
		else if(opt == "6")
		{
			Cards.deleteAll();
			cout<<"Terminating!!! "<<endl;
			break;
		}
		else
		{
			cout <<"Invalid operation! "<<endl;
		}



	}

	return 0;


}

bool cardNumCheck(string cnum)//input check funtions
{
	if(cnum.length() != 16)
		return false;

	for (int i = 0; i < cnum.length(); i++)
	{
		if(cnum[i] < '0' || cnum[i] > '9')
			return false;
	}

	return true;
}

bool bulkDelCheck(string month, string year)//input check funtions
{
	for (int i = 0; i < month.length(); i++)
	{
		if(month[i] < '0' || month[i] > '9')
			return false;
	}

	for (int i = 0; i < year.length(); i++)
	{
		if(year[i] < '0' || year[i] > '9')
			return false;
	}

	if(stoi(month) > 12 || stoi(month) <= 0)
		return false;

	return true;
}



void saveCC(CardList & Cards)//reading file and saving cards 
{
	string file;
	fstream openfile;
	cout << "Please enter file name: ";
	cin >> file;
	cout << endl;
	openfile.open(file.c_str());

	if(openfile.fail())
	{
		cout << "Could not find a file named " << file <<endl;
	}
	else
	{
		string line;
		while(getline(openfile,line))
		{
			istringstream iss(line);
			string creditCardNo;
			int month, year;
			iss >> creditCardNo >> month >> year;

			Cards.insertCard(creditCardNo, month, year);
		}
	}


}
