#include "CreditCards.h"
#include <iostream>

using namespace std;


CardList::CardList()
{
	head = nullptr;
	tail = nullptr;
}


void CardList::insertCard(string creditCardNo, int month, int year)
{

	if(!head)
	{
		head = new expirationNode(month, year,new creditCardNode(creditCardNo));
		tail = head;
		cout << creditCardNo << " " << month << " "<<year<<": added to a new expiration date node"<<endl; //if list is empty it insert node to beginning
	}
	else//trying to find a place for node to insert
	{
		expirationNode * ptr = head;


		bool insertion = false;

		while(ptr != NULL && !insertion)
		{
			if(ptr -> year == year && ptr->month == month) //if an existing node with same year and month is found
			{
				creditCardNode * ptrCredit = ptr->cHead;
				creditCardNode *ptrCtemp = NULL;

				while(ptrCredit != NULL && !insertion)
				{
					if(stod(creditCardNo) < stod(ptrCredit->creditCardNo)) //finding the credit cards place 
					{
						cout << creditCardNo << " " << month << " "<<year<<": inserted to an existing expiration date node"<<endl;
						creditCardNode* ptrCnew = new creditCardNode(creditCardNo, ptrCredit);
						if(ptrCtemp != NULL)
						{
							ptrCtemp->next = ptrCnew;
						}
						else
						{
							ptr->cHead = ptrCnew;
						}
						insertion = true;

					}
					else if(creditCardNo == ptrCredit->creditCardNo)
					{
						cout << creditCardNo << " " << month << " "<<year<<": this card was already inserted "<<endl;//if card already exists
						insertion = true;
					}



					ptrCtemp = ptrCredit;
					ptrCredit = ptrCredit->next;
				}

				if(!insertion)
				{
					creditCardNode* ptrCnew = new creditCardNode(creditCardNo);
					ptrCtemp->next = ptrCnew;
					insertion = true;
					cout << creditCardNo << " " << month << " "<<year<<": inserted to an existing expiration date node"<<endl;//end of cards
				}

			}
			else if(ptr->year > year || (ptr->year == year && ptr->month > month)) //found a new place to insert creditCardNode
			{
				if(ptr->prev == NULL) //inserting before the head
				{
					cout << creditCardNo << " " << month << " "<<year<<": added to a new expiration date node"<<endl;
					expirationNode * ptr2 = new expirationNode(month, year, new creditCardNode(creditCardNo), head, NULL);
					head = ptr2;
					ptr->prev = ptr2;
					insertion = true;
				}
				else
				{
					cout << creditCardNo << " " << month << " "<<year<<": added to a new expiration date node"<<endl;
					expirationNode * ptr2 = new expirationNode(month, year, new creditCardNode(creditCardNo), ptr, ptr->prev);
					ptr->prev->next = ptr2;
					ptr->prev = ptr2;

					insertion = true;

				}
			}

			ptr = ptr->next;
		}

		if(!insertion)//inserting to the end of list
		{
			cout << creditCardNo << " " << month << " "<<year<<": added to a new expiration date node"<<endl;
			ptr= new expirationNode(month, year, new creditCardNode(creditCardNo), NULL, tail);
			tail->next= ptr;
			tail = ptr;


		}



	}






}

void CardList::displayListChronological()
{
	if(head == NULL)
	{
		cout << endl<<"List is empty!" << endl;
		return;
	}


	expirationNode * ptr = head;

	while(ptr)//starts from head and displays every credit card in chronological order
	{
		creditCardNode * ptr2 = ptr->cHead;
		cout << "Expiration Date: " << ptr->month << "  " << ptr->year << endl;
		int i = 1;
		while(ptr2)
		{
			cout << i <<") "<< ptr2->creditCardNo <<endl;
			i++;
			ptr2 = ptr2->next;
		}

		cout << "-------------------" << endl;


		ptr = ptr->next;
	}


}


void CardList::displayListReverseChronological ()
{
	if(head == NULL)
	{
		cout << endl<<"List is empty!" << endl;
		return;
	}


	expirationNode * ptr = tail;//starts from tail and displays every credit card in reverse chronological order

	while(ptr)
	{
		creditCardNode * ptr2 = ptr->cHead;
		cout << "Expiration Date: " << ptr->month << "  " << ptr->year << endl;
		int i = 1;
		while(ptr2)
		{
			cout << i <<") "<< ptr2->creditCardNo <<endl;
			i++;
			ptr2 = ptr2->next;
		}

		cout << "-------------------" << endl;


		ptr = ptr->prev;
	}
}


void CardList::cardSearch (string creditCardNo)
{
	cout<<endl;
	expirationNode * ptr = head;
	bool found = false;
	while (ptr)
	{
		creditCardNode * ptr2 = ptr->cHead;

		while(ptr2)
		{
			if(ptr2->creditCardNo == creditCardNo)
			{
				cout <<"There exists a credit card given number " << creditCardNo << " with expiration date:" << endl << ptr->month << " " << ptr->year <<endl;
				found = true;//saving that we found the credit card in the list
			}


			ptr2 = ptr2->next;
		}



		ptr = ptr->next;
	}

	if(!found)
	{
		cout << endl<<"There is no credit card with given credit card number: " << creditCardNo <<endl;
	}



}


void CardList::bulkDelete (int month, int year)
{
	cout << endl;
	expirationNode * ptr = head;

	while(ptr)
	{
		creditCardNode * ptr2 = ptr->cHead;
		cout << "Node with expiration Date: " << ptr->month << "  " << ptr->year << "  and the following credit cards have been deleted!" <<endl;
		int i = 1;
		while(ptr2)
		{
			cout << i <<") "<< ptr2->creditCardNo <<endl;
			i++;
			creditCardNode * ptrdel = ptr2;
			ptr2 = ptr2->next;
			delete ptrdel;
		}

		if(ptr->month == month && ptr->year==year) //last node is deleted
		{
			expirationNode * ptrdel = ptr;
			ptr = ptr->next;
			head = ptr;
			delete ptrdel;
			ptr->prev = NULL;
			break;
		}


		expirationNode * ptrdel = ptr;
		ptr = ptr->next;
		if(ptr)
		{
			ptr->prev= NULL;
			if(ptr->year > year || (ptr->year == year && ptr->month > month))//exit conditions
				break;
		}
		delete ptrdel;


	}

	if(ptr)
		head = ptr;
	else
	{
		head = NULL;
		tail = NULL;
	}
}

void CardList::deleteAll()
{
	expirationNode* ptr = head;


	while(ptr)
	{
		creditCardNode* cardptr = ptr->cHead;

		while(cardptr)
		{


			creditCardNode * delptr = cardptr;
			cardptr = cardptr->next;
			delete delptr;
		}



		expirationNode* delpt = ptr;
		ptr = ptr->next;
		delete delpt;
	}
	cout <<"All the nodes have been deleted!"<<endl;



}

