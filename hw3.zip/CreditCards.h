#ifndef _CREDITCARDS_H
#define _CREDITCARDS_H

#include <iostream>
#include <string>
using namespace std;

struct creditCardNode  {
	string creditCardNo; 
	creditCardNode * next;    

	creditCardNode(){}

	creditCardNode(string no, creditCardNode * n = NULL): creditCardNo(no), next(n){} //developed constructor
};

struct expirationNode { 
	int month, year; 
	creditCardNode * cHead; 
	expirationNode * next; 
	expirationNode * prev; 

	expirationNode(){}

	expirationNode(int m, int y, creditCardNode * h = NULL, expirationNode * n = NULL, expirationNode * p = NULL ): month(m), year(y), cHead(h), next(n), prev(p){}



};

class CardList  { 
public: 
	CardList(); //default constructor that creates an empty list

	void insertCard (string creditCardNo, int month, int year);    //inserts a new card to the structure in sorted fashion
	void displayListChronological ();  //displays entire structure in chronological order 
	void displayListReverseChronological ();  //displays entire structure in reverse chronological order
	void cardSearch (string creditCardNo);  //displays all of the occurrences of the given card number 
	void bulkDelete (int month, int year);  //deletes all nodes up to and including given expiration date
	void deleteAll (); //deletes the entire structure 
private:  
	expirationNode * head; 
	expirationNode * tail; 

	// any helper functions you see necessary 
}; 

#endif