#include <iostream>
#include <string>
#include<fstream>
#include "header.h"

using namespace std;



bool control(string &s){  
	bool isInteger = (s.find_first_not_of( "0123456789" ) == string::npos);  //checks the string is integer or not.

	if (isInteger)
		if (stoi(s)<3) //looking wheter is smaller than 3
			return false;


	return isInteger;
	
}

bool startingpointcheck(string &row,string &col,int r,int c){  //another input check for comparison to row and column size too
	bool isBothInteger = (row.find_first_not_of( "0123456789" ) == string::npos && col.find_first_not_of( "0123456789" ) == string::npos);
	//checks the both strings are integer or not.
if(isBothInteger)
	if(stoi(row)>=r || stoi(col)>=c )
		return false;

	return isBothInteger;
	
}


int main() {
	cout << "Enter the number of rows: ";
    string r;
	
    cin >> r;
	while(!control(r) ){
			cout <<r <<" is not valid! "<<endl;
			cout << "Enter the number of rows: ";
			cin >> r;
	}
	int row=stoi(r); //converting string to int

    cout << "Enter the number of columns: ";
    string c;
    cin>> c;
	while(!control(c)){
			cout <<c <<" is not valid!"<<endl;
			cout << "Enter the number of columns: ";
			cin >> c;
	}
	int col=stoi(c); //converting string to int

	ifstream input;
    cout << "Please enter file name: " ;
	string file;
	cin >> file;
	input.open(file.c_str());
	while (input.fail())
		{
			cout << "Cannot open a file named " << file << endl;
			cout << "Please enter file name: ";
			cin >> file;
			input.open(file.c_str());
		}
	string line;

	//creating our array.
	char **headofarray = 0;
	headofarray = new char *[row]; //dynamic
	for (int i=0; i < row; i++)
		headofarray[i] = new char [col];

//	---> [   ]
//	---> [   ]      CREAT�NG 2 D ARRAY LIKE THIS SHAPE, headofarray[integer] gives us the column pointers.
//	---> [   ]
//	---> [   ]
//    ^
//    |  -> headofarray
///


  int m=0;
	while (getline(input, line))//reading the txt to our array
	{ for (int i=0; i < col; i++)
			headofarray[m][i]=line[i]; 
		 m++;
	}
	
	

	cout << "Enter the starting point: " ;
	string srow,scol;
	cin>>srow>>scol;



	while(!startingpointcheck(srow,scol,row,col))	
	{cout << "Invalid coordinate! "<<endl ;
	cout << "Enter the starting point: " ;
	cin>>srow>>scol;
	}
	int startrow=stoi(srow);
	int startcol=stoi(scol);

	if(headofarray[startrow][startcol]=='X') //if starting point, is not empty char it means it is occupied.
		{cout<<"Starting point is already occupied."<<endl;
	return 0;
	}

	char cr;
	cout << "Enter the filling char: " ;
	cin>>cr;
	while (cr=='X' || cr=='x'){
	cout << "Filling char is not valid! "<<endl ;
	cout << "Enter the filling char: ";
	cin>>cr;
	}


	headofarray[startrow][startcol]=cr; //sign the starting point with our f�ll�ng char
	Stack stack;
	stack.push(startrow,startcol); //push our starting point.


	while(!stack.isEmpty()){ //if stack empty, finish the operation
	
		 if(headofarray[startrow+1][startcol]!='X' && headofarray[startrow+1][startcol]!=cr) //looking south
		{	stack.push(startrow+1,startcol);
			headofarray[startrow+1][startcol]=cr;
			startrow++;

		}
		else if(headofarray[startrow-1][startcol]!='X' && headofarray[startrow-1][startcol]!=cr) //looking north
		{
			stack.push(startrow-1,startcol);
			headofarray[startrow-1][startcol]=cr;
			startrow--;

		}
		
		 else if(headofarray[startrow][startcol+1]!='X' && headofarray[startrow][startcol+1]!=cr) //looking east
		{	stack.push(startrow,startcol+1);
			headofarray[startrow][startcol+1]=cr;
			startcol++;

		}

		else if(headofarray[startrow][startcol-1]!='X' && headofarray[startrow][startcol-1]!=cr) //looking west
		{	stack.push(startrow,startcol-1);
			headofarray[startrow][startcol-1]=cr;
			startcol--;

		}
		
		else  //if can not get any if �t means all edges are X,now pop the stack
		{	
			node * p=stack.pop();
			if(stack.isEmpty()) //if the last pop operation makes the stack empty, finish our operation. otherwise pop one more time to get last steps information.
				break;
			p=stack.pop();
			startcol=p->col;
			startrow=p->row;
			stack.push(startrow,startcol);

		}
	
	}

		for(int i = 0; i < row; i++)
		{for(int m = 0; m < col; m++)    //printing resulting array
			cout<< headofarray[i][m];
			cout<<endl;
		}

		for(int i = 0; i < row; ++i) {  // to prevent memory leaks our matrix deleted.
				delete [] headofarray[i];
				}
delete [] headofarray;

return 0;



	
}