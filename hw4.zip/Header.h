#ifndef HEADER_H
#define HEADER_H
	struct node  //a data structure for needed coordinate information. will be used in stack
{
int row;
int col;

node *next;
node(  int & row, int & col,node * n = nullptr)
:row( row ), col( col ),next(n){ }
};

class Stack  
{
 
public:


Stack( );
~Stack( ); //destructor
bool isEmpty( ) ;
node * pop( ){  //LAST ELEMENT WILL BE deleted and its copy will returned as pointer. 
	{
	node * oldhead=head;
	head=oldhead->next;
	node * rt=new node( oldhead->row, oldhead->col);
	delete oldhead;
	count --;	
	return rt;
}

}
void push( int row, int col ); //a member function, that takes row and col as argument 
// creates node and inserts it on top of stack
private:
	
	node *head;
	int count;

};

Stack::Stack(){ //creating stack with constructor.
	head=nullptr;
	count=0;  //count would be benefical for debugging
}
Stack::~Stack( ){  //destructor , will called automaticly     
 head = nullptr;
 count=0;
}

bool Stack::isEmpty( ) 
{
return count == 0;
}

void Stack::push( int row, int col){ //LAST ELEMENT WILL BE THE HEAD OF STACK and next pointer points the old head. 
	
	node * p=new node( row,col);
	node *oldhead=head;
	p->next=oldhead;
	head=p;
	count++; //we push somethin, update the count for tracking.
	
}

#endif