#include <iostream>
#include <string>
using namespace std;

int main(){
	
	string key,plaintext;
	cout <<"*** Welcome to the Simple Data Encryption Application ***"<< endl;
	cout <<"Please enter the encryption key: ";
	getline(cin,key);  //intead of cin>>key 

	cout<<"Please enter the plaintext to be encrypted: ";

	while(getline(cin,plaintext)){  //unless the user enters ctrl z
		cout<<"Ciphertext: ";
		for(int i=0; i< plaintext.length(); i++ ){  // it goes through all the characters one by one
			unsigned char single_result, result;
			unsigned char ch1 = plaintext[i];
			single_result= ((ch1 & 0x01)<<2) | ((ch1 & 0x02) >> 1) | ((ch1 & 0x04) << 1) | ((ch1 & 0x08) >> 2) | ((ch1 & 0x10) << 2) | ((ch1 & 0x20) >> 1) | ((ch1 & 0x40) << 1) | ((ch1 & 0x80) >> 2); 
			
			unsigned char ch2 = key[i % key.length()]; //%: for ex. if key is shorter than text, it goes back to the beginning after the last index
			result = single_result^ch2;  //xor operation
			cout << hex << (int) result; 	
		}
		cout << endl <<  "\nPlease enter the plaintext to be encrypted: ";
	}
	return 0;	
}